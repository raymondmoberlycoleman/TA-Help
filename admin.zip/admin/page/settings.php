<?php
include_once( dirname(dirname(dirname(__FILE__))) . '/classes/check.class.php');
protect("1");

include_once('../classes/settings.class.php');
?>