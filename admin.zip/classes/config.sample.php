<?php

$host = "localhost"; //  localhost
$dbName = "database"; // Database name
$dbUser = "username"; // Username
$dbPass = "password"; // Password

?>