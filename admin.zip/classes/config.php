<?php


$host = "localhost"; // localhost
$dbName = "cmackay_tahelp"; // Database name
$dbUser = "cmackay_kevin"; // Username
$dbPass = "bb212121"; // Password

?>